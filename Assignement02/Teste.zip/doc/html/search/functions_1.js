var searchData=
[
  ['checksum_40',['CheckSum',['../group__Uart.html#ga77e129fc98b3b9c3c28ae4eab0c88fe3',1,'CheckSum(unsigned char *buf, int nbytes):&#160;Uart.c'],['../group__Uart.html#ga77e129fc98b3b9c3c28ae4eab0c88fe3',1,'CheckSum(unsigned char *buf, int nbytes):&#160;Uart.c']]],
  ['cmdproc_41',['cmdProc',['../group__Uart.html#gaced3facd7540036687482d443d6aecde',1,'cmdProc(void):&#160;Uart.c'],['../group__Uart.html#gaced3facd7540036687482d443d6aecde',1,'cmdProc(void):&#160;Uart.c']]]
];
