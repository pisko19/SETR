var indexSectionsWithContent =
{
  0: "aceglmnrstuv",
  1: "tu",
  2: "acgnrt",
  3: "u",
  4: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "groups",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Modules",
  4: "Pages"
};

