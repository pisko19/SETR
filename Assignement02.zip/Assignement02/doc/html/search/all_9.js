var searchData=
[
  ['size_5ferror_28',['Size_Error',['../group__Uart.html#ga0e91e847a955cfeca08d6f3a5a89210b',1,'Uart.h']]],
  ['smart_20sensor_20uart_20module_29',['Smart Sensor UART Module',['../index.html',1,'']]],
  ['sos_30',['SOS',['../group__Uart.html#gaaba783a919ec55e409334086e6d2a3bb',1,'Uart.h']]],
  ['sos_5ferror_31',['SOS_Error',['../group__Uart.html#gabdb71014872b37b4c583b5ade7dc40e0',1,'Uart.h']]]
];
