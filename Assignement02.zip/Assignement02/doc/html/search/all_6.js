var searchData=
[
  ['max_5fsize_23',['MAX_SIZE',['../group__Uart.html#ga0592dba56693fad79136250c11e5a7fe',1,'Uart.h']]]
];
