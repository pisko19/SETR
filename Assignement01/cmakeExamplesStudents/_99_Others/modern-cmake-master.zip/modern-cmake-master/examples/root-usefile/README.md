# A Simple ROOT Project

This is a minimal example of a ROOT project using the UseFile system and without a dictionary.

#### examples/root-usefile/CMakeLists.txt

[import:'main', lang:'cmake'](CMakeLists.txt)

#### examples/root-usefile/SimpleExample.cxx

[import](SimpleExample.cxx)
