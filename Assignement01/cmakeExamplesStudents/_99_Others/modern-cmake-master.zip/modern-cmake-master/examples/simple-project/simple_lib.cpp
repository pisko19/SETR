#include <string>

std::string simple_lib_function() {
    return "Compiled in library";
}
