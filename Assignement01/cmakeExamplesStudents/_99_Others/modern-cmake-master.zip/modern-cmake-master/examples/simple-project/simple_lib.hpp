#pragma once

#include <string>

std::string simple_lib_function();
