#include "DictExample.h"

Double_t Simple::GetX() const {return x;}

ClassImp(Simple)
