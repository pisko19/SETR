# A Simple ROOT Project

This is a minimal example of a ROOT project using the target system and without a dictionary.

#### examples/root-simple/CMakeLists.txt

[import:'main', lang:'cmake'](CMakeLists.txt)

#### examples/root-simple/SimpleExample.cxx

[import](SimpleExample.cxx)
