# Documentation for Modern Library {#mainpage}

This is the documentation for my simple example library.

It is good documentation because:

1. It exists.
2. I wrote it.
3. Everything is documented (pretty easy since there's only one function)

The single provided function is `::accumulate_vector`.
