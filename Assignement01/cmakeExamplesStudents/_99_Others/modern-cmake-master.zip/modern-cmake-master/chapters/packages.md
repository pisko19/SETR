# Finding Packages

There are two ways to find packages in CMake: "Module" mode and "Config" mode.
