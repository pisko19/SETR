# Including Small Projects

This is where a good Git system plus CMake shines. You might not be able to solve all the world's problems, but
this is pretty close for C++!

There are several methods listed in the chapters in this section.
