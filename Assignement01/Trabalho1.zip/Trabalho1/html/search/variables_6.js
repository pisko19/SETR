var searchData=
[
  ['tail_67',['Tail',['../group__MyDLL.html#ga9207531e02e793ed3698ce9a5aa9d241',1,'DLL_List']]]
];
