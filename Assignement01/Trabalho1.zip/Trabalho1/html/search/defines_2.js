var searchData=
[
  ['notkey_55',['NotKey',['../MyDLL_8h.html#a375faf90c5c25165d32e4ba2bc2d8633',1,'MyDLL.h']]],
  ['notkeyint_56',['NotKeyInt',['../MyDLL_8h.html#ad966757bf39e47e1aa0d99ba215adcfc',1,'MyDLL.h']]]
];
