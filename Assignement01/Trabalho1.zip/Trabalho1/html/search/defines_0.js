var searchData=
[
  ['full_52',['FULL',['../MyDLL_8h.html#a7b05b8118861711fd8573e92759bbc34',1,'MyDLL.h']]]
];
