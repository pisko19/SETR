var searchData=
[
  ['max_5felem_5fsize_53',['MAX_ELEM_SIZE',['../MyDLL_8h.html#aa84da8be2a5293eca8340e41e267af15',1,'MyDLL.h']]],
  ['max_5flist_5fsize_54',['MAX_LIST_SIZE',['../MyDLL_8h.html#a52a03eea6b90f6bc967ed15a7e6a36b9',1,'MyDLL.h']]]
];
