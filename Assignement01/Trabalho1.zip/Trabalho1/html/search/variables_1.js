var searchData=
[
  ['head_61',['Head',['../group__MyDLL.html#ga5c5f18210d549ed4508a67f51da9d223',1,'DLL_List']]]
];
