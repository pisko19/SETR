var searchData=
[
  ['ok_25',['OK',['../group__MyDLL.html#gaba51915c87d64af47fb1cc59348961c9',1,'MyDLL.h']]]
];
