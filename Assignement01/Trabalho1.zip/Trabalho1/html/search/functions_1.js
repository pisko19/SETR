var searchData=
[
  ['swapnodes_52',['swapNodes',['../group__MyDLL.html#ga92efe67fd3766987f054bac6afc0161a',1,'swapNodes(MyDLL *a, MyDLL *b):&#160;MyDLL.c'],['../group__MyDLL.html#ga92efe67fd3766987f054bac6afc0161a',1,'swapNodes(MyDLL *a, MyDLL *b):&#160;MyDLL.c']]]
];
