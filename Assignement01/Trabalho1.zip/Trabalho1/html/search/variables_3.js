var searchData=
[
  ['next_63',['Next',['../group__MyDLL.html#ga2b0214424e470fa9d2c827c0971b22ef',1,'MyDLL']]],
  ['nodes_64',['nodes',['../group__MyDLL.html#gafde85a988aed6a4eb2413fef9dfee656',1,'DLL_List']]]
];
